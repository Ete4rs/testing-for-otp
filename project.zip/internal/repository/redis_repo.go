package repository

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/google/uuid"
	goredis "github.com/redis/go-redis/v9"
)

const (
	MaxOTPAttempts   = 5
	OTPAttemptTTL    = 2 * time.Minute
	OTPAttemptKeyFmt = "otp-attempts:%s" // sessionID will go here
)

type otpSession struct {
	Phone string `json:"phone"`
	OTP   string `json:"otp"`
}

func GenerateSessionForOTP(phone string, otp string, rdb *goredis.Client) (string, error) {
	ctx := context.Background()
	sessionID := uuid.New().String()
	key := fmt.Sprintf("otp-session:%s", sessionID)

	payload := otpSession{
		Phone: phone,
		OTP:   otp,
	}

	data, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}
	err = rdb.Set(ctx, key, data, 2*time.Minute).Err()
	if err != nil {
		return "", err
	}

	return sessionID, nil
}

func VerifySession(sessionID string, rdb *goredis.Client) (*otpSession, error) {
	ctx := context.Background()
	key := fmt.Sprintf("otp-session:%s", sessionID)

	data, err := rdb.Get(ctx, key).Result()
	if err == goredis.Nil {
		return nil, errors.New("session not found or expired")
	} else if err != nil {
		return nil, err
	}
	var session otpSession
	err = json.Unmarshal([]byte(data), &session)
	if err != nil {
		return nil, errors.New("invalid session data")
	}

	if session.Phone == "" {
		return nil, errors.New("phone number missing in session")
	}
	return &session, nil
}

func CheckOTPAttempts(sessionID string, rdb *goredis.Client) error {
	ctx := context.Background()
	attemptKey := fmt.Sprintf(OTPAttemptKeyFmt, sessionID)

	attempts, err := rdb.Get(ctx, attemptKey).Int()
	if err != nil && err != goredis.Nil {
		return fmt.Errorf("failed to check attempt count: %w", err)
	}

	if attempts >= MaxOTPAttempts {
		return errors.New("too many incorrect OTP attempts")
	}

	return nil
}

func IncrementOTPAttempt(sessionID string, rdb *goredis.Client) error {
	ctx := context.Background()
	attemptKey := fmt.Sprintf(OTPAttemptKeyFmt, sessionID)

	pipe := rdb.TxPipeline()
	pipe.Incr(ctx, attemptKey)
	pipe.Expire(ctx, attemptKey, OTPAttemptTTL) // reset TTL if key is new
	_, err := pipe.Exec(ctx)
	return err
}

func ResetOTPAttempts(sessionID string, rdb *goredis.Client) error {
	ctx := context.Background()
	return rdb.Del(ctx, fmt.Sprintf(OTPAttemptKeyFmt, sessionID)).Err()
}
