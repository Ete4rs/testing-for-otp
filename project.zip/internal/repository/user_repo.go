package repository

import (
	"dekamond/internal/domain"
	"strings"

	"gorm.io/gorm"
)

func UserSignupRequestHandler(u *domain.User, db *gorm.DB) error {
	err := db.Create(&u).Error
	if err != nil && strings.Contains(err.Error(), "Error 1062") {
		return nil
	}
	return err
}
