package domain

type User struct {
	PhoneNumber string `gorm:"column:phone_number;unique" json:"phone"`
}

type OTP struct {
	OTPPasword string `json:"otp"`
}
