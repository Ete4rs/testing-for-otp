package utils

import (
	"crypto/rand"
	"fmt"
)

func CreateOTPPassword() string {
	var number int64
	b := make([]byte, 4)
	_, err := rand.Read(b)
	if err != nil {
		return "000000"
	}
	number = int64(b[0])<<24 | int64(b[1])<<16 | int64(b[2])<<8 | int64(b[3])
	number = number % 1000000

	return fmt.Sprintf("%06d", number)
}
