package transport

import (
	"dekamond/internal/handler"

	"github.com/gin-gonic/gin"
	goredis "github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

func SetupRoutes(router *gin.Engine, mdb *gorm.DB, rdb *goredis.Client) {
	authHandler := handler.NewAuthHandler(mdb, rdb)

	api := router.Group("/api")
	{
		api.POST("/user", authHandler.SignUp)
		api.POST("/verify-otp", authHandler.VerifyOTP)
	}
}
