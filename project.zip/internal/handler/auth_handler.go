package handler

import (
	"dekamond/internal/domain"
	"dekamond/internal/repository"
	"dekamond/internal/utils"
	"fmt"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	goredis "github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

type AuthHandler struct {
	db  *gorm.DB
	rdb *goredis.Client
}

func NewAuthHandler(mdb *gorm.DB, redisDB *goredis.Client) *AuthHandler {
	return &AuthHandler{db: mdb, rdb: redisDB}
}

func (h *AuthHandler) SignUp(c *gin.Context) {
	user := domain.User{}
	err := c.ShouldBindBodyWithJSON(&user)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": err.Error()})
		return
	}
	err = repository.UserSignupRequestHandler(&user, h.db)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": err.Error()})
		return
	}
	otp := utils.CreateOTPPassword()
	sessionID, err := repository.GenerateSessionForOTP(user.PhoneNumber, otp, h.rdb)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"err": err.Error()})
		return
	}
	log.Println(" signed , otp = ", otp) //log the otp
	c.SetCookie("otp_session", sessionID, 120, "/", "localhost", false, true)
	fmt.Println(sessionID)
	c.JSON(http.StatusOK, gin.H{"message": "signup endpoint hit"})
}

// OTP validation and token creation
func (h *AuthHandler) VerifyOTP(c *gin.Context) {
	otp := domain.OTP{}
	err := c.ShouldBindBodyWithJSON(&otp)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": err.Error()})
		return
	}
	sessionID, err := c.Cookie("otp_session")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": "Missing or expired session"})
		return
	}
	c.SetCookie("otp_session", "", -1, "/", "localhost", false, true)
	err = repository.CheckOTPAttempts(sessionID, h.rdb)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": err.Error()})
		return
	}
	session, err := repository.VerifySession(sessionID, h.rdb)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": err.Error()})
		return
	}
	if otp.OTPPasword != session.OTP {
		repository.IncrementOTPAttempt(sessionID, h.rdb)
		c.JSON(http.StatusBadRequest, gin.H{"err": "wrong otp"})
		return
	}
	token, err := utils.GenerateJWT(session.Phone)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"err": err.Error()})
		return
	}
	repository.ResetOTPAttempts(sessionID, h.rdb)
	c.JSON(http.StatusOK, gin.H{"message": token})
}
