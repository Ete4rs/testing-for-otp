package main

import (
	"context"
	"dekamond/config"
	"dekamond/internal/transport"
	"fmt"
	"log"
	"time"

	"github.com/gin-gonic/gin"

	goredis "github.com/redis/go-redis/v9"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

func main() {
	cfg := config.LoadConfig()

	mdb := initMysql(cfg)
	rdb := initRedis(cfg)
	router := gin.Default()

	transport.SetupRoutes(router, mdb, rdb)

	addr := fmt.Sprintf(":%s", cfg.Port)
	log.Printf("Server running on %s", addr)
	if err := router.Run(addr); err != nil {
		log.Fatalf("Failed to run server: %v", err)
	}
}

func initMysql(cfg config.Config) *gorm.DB {
	db, err := gorm.Open(mysql.Open(cfg.MySQLDSN), &gorm.Config{})
	if err != nil {
		log.Fatalf("❌ Failed to connect to MySQL: %v", err)
	}
	log.Println("✅ MySQL connected")
	return db
}

func initRedis(cfg config.Config) *goredis.Client {
	rdb := goredis.NewClient(&goredis.Options{
		Addr:     cfg.RedisAddr,
		Password: cfg.RedisPwd,
		DB:       0,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatalf("Redis connection failed: %v", err)
	}

	log.Println(" Redis connected")
	return rdb
}
