package config

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

type Config struct {
	MySQLDSN  string
	RedisAddr string
	RedisPwd  string
	Port      string
}

func LoadConfig() Config {
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using system env vars")
	}
	return Config{
		MySQLDSN:  getEnv("MYSQL_DSN", "root:password@tcp(127.0.0.1:3306)/authdb?parseTime=true"),
		RedisAddr: getEnv("REDIS_ADDR", "localhost:6379"),
		RedisPwd:  getEnv("REDIS_PASSWORD", ""),
		Port:      getEnv("PORT", "8080"),
	}
}

func getEnv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	log.Printf("Using fallback for %s", key)
	return fallback
}
