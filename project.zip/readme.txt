1-login (or singup) by otp is handling by session and then after done , user will get a jwt token

2-database is mysql

3-i used redis for limiting otp request and for session storing

4-architecture is clean architecture , just for being fastly develop and maintainability and ... 

5-the api file of postman has been shared too

6-gin framework

7-gorm for database

8- OS = ubuntu
    
9-docker file is shared too

10-makefile is shared too